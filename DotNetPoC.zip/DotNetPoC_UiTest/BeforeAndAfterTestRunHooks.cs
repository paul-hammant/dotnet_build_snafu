using System.Threading;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;

namespace DotNetPoC.UiTest
{
    [Binding]
    public class BeforeAndAfterTestRunHooks
    {
        private static CancellationTokenSource _cancelToken = new CancellationTokenSource();

        public static IWebDriver? Driver;
        
        [BeforeTestRun]
        public static void BeforeTestRun()
        {

            Driver = new ChromeDriver();
            
            Host.CreateDefaultBuilder().ConfigureWebHostDefaults(webbuilder =>
            {
                webbuilder.UseStartup<TestExtendedDotNetPoCStartup>();
            }).Build().RunAsync(_cancelToken.Token);

        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
            _cancelToken.Cancel();
            Driver.Quit();
        }

    }
}
